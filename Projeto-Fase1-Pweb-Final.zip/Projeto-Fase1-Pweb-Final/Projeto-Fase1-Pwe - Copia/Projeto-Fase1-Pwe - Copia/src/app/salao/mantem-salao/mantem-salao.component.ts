import { Component } from '@angular/core';
import {Salao} from '../../shared/modelo/salao';
import {SALOES} from '../../shared/modelo/SALOES';
import {ActivatedRoute, Router} from '@angular/router';
import {SalaoService} from "../../shared/services/salao.service";

@Component({
  selector: 'app-mantem-jogador',
  templateUrl: './mantem-salao.component.html',
  styleUrls: ['./mantem-salao.component.css']
})
export class MantemSalaoComponent {

  salaoDeManutencao: Salao;
  estahCadastrando = true;
  nomeBotaoManutencao = 'Cadastrar';

  saloes = SALOES;
  constructor(private rotaAtual: ActivatedRoute, private roteador: Router, private SalaoService: SalaoService) {
    this.salaoDeManutencao = new Salao('', '', '');
    const idParaEdicao = this.rotaAtual.snapshot.paramMap.get('id');
    this.SalaoService.listar().subscribe(
      saloesRetornados => {
        this.saloes = saloesRetornados;

        if (idParaEdicao) {
      this.SalaoService.pesquisarPorId(+idParaEdicao).subscribe(
        salaoEncontrado => {
          this.salaoDeManutencao = salaoEncontrado
          this.estahCadastrando = false;
          this.nomeBotaoManutencao = 'Salvar'}
      )

    } else {
      this.nomeBotaoManutencao = 'Cadastrar';

    }
  })
}


  manter(): void {
  //   if (this.estahCadastrando && this.salaoDeManutencao) {
  //     this.saloes.push(this.salaoDeManutencao);
  //   }
  //   this.salaoDeManutencao = new Salao();
  //   this.nomeBotaoManutencao = 'Cadastrar';
  //   this.roteador.navigate(['listagemsaloes']);//
  // }


  if (this.estahCadastrando && this.salaoDeManutencao) {
  this.SalaoService.inserir(this.salaoDeManutencao).subscribe(
    salaocadastrado=>{
  this.salaoDeManutencao = new Salao();
  this.nomeBotaoManutencao = 'Cadastrar';
  this.roteador.navigate(['listagemsaloes']);
}
)

}
else{
  this.SalaoService.atualizar(this.salaoDeManutencao).subscribe(
    salaocadastrado=>{
      this.salaoDeManutencao = new Salao();
      this.nomeBotaoManutencao = 'Cadastrar';
      this.roteador.navigate(['listagemsaloes']);
    }
  )
}

}
atualizar() {
  this.SalaoService.atualizar(this.salaoDeManutencao).subscribe()
}

}
