import {Salao} from './salao';

export const SALOES: Array<Salao> = [
  {
    id: 1,
    nome: 'Salão XYZ',
    endereco: 'Rua XXX',
    dono:'José'
  }


]
