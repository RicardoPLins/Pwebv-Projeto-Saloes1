export class Salao {

  constructor(
              public nome = '',
              public endereco?: string,
              public dono: string = '',
              public id?: number) {
  }
}
